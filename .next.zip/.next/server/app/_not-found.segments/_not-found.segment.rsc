1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/4e6039707628a6ab.js","/_next/static/chunks/fbab8f1a69a7f961.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
3:I[37457,["/_next/static/chunks/4e6039707628a6ab.js","/_next/static/chunks/fbab8f1a69a7f961.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
0:{"buildId":"CEBMi8DsVU7ftjTYPJKU3","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
