:HL["/_next/static/chunks/587acff0b6e4b8bc.css","style"]
:HL["/_next/static/chunks/07647a8dce7e9f09.css","style"]
0:{"buildId":"CEBMi8DsVU7ftjTYPJKU3","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"/_not-found","paramType":null,"paramKey":"/_not-found","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
