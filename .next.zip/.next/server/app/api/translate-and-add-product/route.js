var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/translate-and-add-product/route.js")
R.c("server/chunks/[root-of-the-server]__54bde0c6._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_translate-and-add-product_route_actions_82cc3b89.js")
R.m(39230)
module.exports=R.m(39230).exports
