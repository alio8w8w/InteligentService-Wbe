var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/blocks/route.js")
R.c("server/chunks/[root-of-the-server]__528f8c30._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_f06d336e._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_blocks_route_actions_de3b5b54.js")
R.m(29239)
module.exports=R.m(29239).exports
