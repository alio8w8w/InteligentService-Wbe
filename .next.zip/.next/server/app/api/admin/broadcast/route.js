var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/broadcast/route.js")
R.c("server/chunks/[root-of-the-server]__128efda5._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_f06d336e._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_broadcast_route_actions_7af86038.js")
R.m(24186)
module.exports=R.m(24186).exports
