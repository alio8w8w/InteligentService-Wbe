var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/guest-cart/route.js")
R.c("server/chunks/[root-of-the-server]__92a08540._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_guest-cart_route_actions_dc3031ec.js")
R.m(58715)
module.exports=R.m(58715).exports
