globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/aece3d2484af6806.js",
    "static/chunks/8a7f6ceba26d3edc.js",
    "static/chunks/7768470368a546b5.js",
    "static/chunks/aee6c7720838f8a2.js",
    "static/chunks/40f1846f7d007f42.js",
    "static/chunks/turbopack-bc36b176ac79710c.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];