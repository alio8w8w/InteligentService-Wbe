module.exports=[83073,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_produse_page_actions_fca3d8a4.js.map