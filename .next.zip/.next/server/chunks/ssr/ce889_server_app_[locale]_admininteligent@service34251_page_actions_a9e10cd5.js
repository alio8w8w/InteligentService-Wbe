module.exports=[65016,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%5Blocale%5D_admininteligent%40service34251_page_actions_a9e10cd5.js.map