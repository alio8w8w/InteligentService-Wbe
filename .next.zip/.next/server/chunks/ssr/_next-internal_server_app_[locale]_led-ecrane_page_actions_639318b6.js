module.exports=[38032,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_led-ecrane_page_actions_639318b6.js.map