module.exports=[22170,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_branduri_page_actions_9a528983.js.map