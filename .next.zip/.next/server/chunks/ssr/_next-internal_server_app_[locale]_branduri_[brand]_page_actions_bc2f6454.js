module.exports=[51254,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_branduri_%5Bbrand%5D_page_actions_bc2f6454.js.map