module.exports=[28759,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%5Blocale%5D_admininteligent%40service34251_admin_page_actions_0271a546.js.map