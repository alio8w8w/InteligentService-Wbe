module.exports=[73083,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_cos_page_actions_848d6f5b.js.map