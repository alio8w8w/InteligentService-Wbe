module.exports=[16729,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_galerie_page_actions_196e98e4.js.map