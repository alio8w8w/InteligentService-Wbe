module.exports=[12285,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_translate-and-add-product_route_actions_82cc3b89.js.map