module.exports=[38433,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_blocks_route_actions_de3b5b54.js.map